public class Sprinkles implements IceCreamTopping{

    public String name;
    public double price;

    public Sprinkles(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public double getPrice() {
        return 0.30;
    }

    @Override
    public String getName() {
        return "Sprinkles";
    }
}
