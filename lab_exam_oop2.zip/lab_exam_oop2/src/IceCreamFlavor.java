interface IceCreamFlavor
{
    String getName();
    double getPricePerScoop();
}

