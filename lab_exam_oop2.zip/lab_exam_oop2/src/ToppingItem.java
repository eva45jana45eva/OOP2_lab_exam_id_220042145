interface ToppingItem {


    public double calculatePrice();


    public String getDescription() ;

}