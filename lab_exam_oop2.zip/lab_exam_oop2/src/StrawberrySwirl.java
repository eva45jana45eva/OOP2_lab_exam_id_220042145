public class StrawberrySwirl implements IceCreamFlavor {




        @Override
        public String getName() {
            return "StrawberrySwirl";
        }

        @Override
        public double getPricePerScoop() {
            return 2.75;
        }
    }
