class OrderItem {
    private IceCreamFlavor flavor;
    private int scoops;

    public OrderItem(IceCreamFlavor flavor, int scoops) {//DIP
        this.flavor = flavor;
        this.scoops = scoops;
    }

    public double calculatePrice() {
        return flavor.getPricePerScoop() * scoops;
    }

    public String getDescription() {
        return flavor.getName() + " - " + scoops + " scoop(s): $" + calculatePrice();
    }
}