public class ToppingItemImp implements ToppingItem {
    IceCreamTopping topping;
     int quantity;

    public ToppingItemImp(IceCreamTopping topping, int quantity) {
        this.topping = topping;
        this.quantity = quantity;
    }

    @Override
    public double calculatePrice() {
        return topping.getPrice() * quantity;
    }

    @Override
    public String getDescription() {
        return topping.getName() + " - " + quantity + " time(s): $" + calculatePrice();
    }
}
