import java.util.ArrayList;
import java.util.List;

class Order {
    private List<OrderItem> flavorItems;//interface
    private List<ToppingItem> toppingItems;//interface dip
    private boolean waffleCone;

    public Order(boolean waffleCone) {
        this.flavorItems = new ArrayList<>();
        this.toppingItems = new ArrayList<>();
        this.waffleCone = waffleCone;
    }

    public void addFlavorItem(OrderItem item) {
        flavorItems.add(item);
    }

    public void addToppingItem(ToppingItem item) {
        toppingItems.add(item);
    }

    public double calculateSubtotal() {
        double subtotal = 0;
        for (OrderItem item : flavorItems) {
            subtotal += item.calculatePrice();
        }
        for (ToppingItem item : toppingItems) {
            subtotal += item.calculatePrice();
        }
        if (waffleCone) {
            subtotal += 5.00;
        }
        return subtotal;
    }

    public double calculateTax() {
        return calculateSubtotal() * 0.08;
    }

    public double calculateTotal() {
        return calculateSubtotal() + calculateTax();
    }

    public String generateInvoice() {
        StringBuilder invoice = new StringBuilder("Ice Cream Shop Invoice");
        for (OrderItem item : flavorItems) {

            System.out.println("item.getDescription()");
        }
        for (ToppingItem item : toppingItems) {

            System.out.println(item.getDescription());
        }
        if (waffleCone) {

            System.out.println("Waffle Cone: $5.00\n");
        } else {

            System.out.println("Paper Cup: $0.00\n");
        }

        System.out.println(calculateSubtotal());

        System.out.println(calculateTax());

        System.out.println(calculateTotal());
        return invoice.toString();
    }
}