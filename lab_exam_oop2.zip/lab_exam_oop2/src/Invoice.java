import java.io.FileWriter;
import java.io.IOException;

class Invoice {
    public static void generateInvoiceFile(Order order, String filename) {
        try (FileWriter writer = new FileWriter(filename)) {


            writer.write(order.generateInvoice());
        } catch (IOException e) {
            System.out.println("An error occurred while generating the invoice file.");
        }
    }
}