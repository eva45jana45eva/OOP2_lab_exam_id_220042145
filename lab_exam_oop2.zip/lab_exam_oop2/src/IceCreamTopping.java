interface IceCreamTopping {


    public double getPrice() ;
    public String getName();


}