public class ChocolateFudge implements  IceCreamFlavor
{
    String chocolate;
    double v;
    public ChocolateFudge(String chocolate, double v) {
        this.chocolate = chocolate;
    }
    @Override
    public String getName() {
        return chocolate;
    }

    @Override
    public double getPricePerScoop() {
        return v;
    }
}