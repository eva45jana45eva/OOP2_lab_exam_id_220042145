public class MintChocolateChip implements  IceCreamFlavor
{
     String name;
     double pricePerScoop;


    public MintChocolateChip(String name, double pricePerScoop) {
        this.name = name;
        this.pricePerScoop = pricePerScoop;
    }

    @Override
    public String getName() {
        return "MintChocolateChip";
    }

    @Override
    public double getPricePerScoop() {
        return 2.80;
    }
}