import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class testing {
    @Test
    public void testSubtotalCalculation() {
        IceCreamFlavor flavor = new MintChocolateChip("MintChocolateChip", 2.5);
        OrderItem item = new OrderItem(flavor, 3);
        Order order = new Order(false);
        order.addFlavorItem(item);

        assertEquals(8.399999999999999, order.calculateSubtotal(), 0.01);
    }

    @Test
    public void testTotalCalculationWithTax() {
        IceCreamFlavor flavor = new ChocolateFudge("Chocolate", 3.0);
        IceCreamTopping topping = new Sprinkles("Sprinkles", 1.5);
        OrderItem flavorItem = new OrderItem(flavor, 2);
        ToppingItem toppingItem = new ToppingItemImp(topping, 1) {

        };
        Order order = new Order(true);
        order.addFlavorItem(flavorItem);
        order.addToppingItem(toppingItem);

        assertEquals(12.204, order.calculateTotal(), 0.01);
    }

    @Test
    public void testWaffleConeAddition() {
        Order order = new Order(true);
        assertEquals(5.00, order.calculateSubtotal(), 0.01);
    }


@Test
    public void testToppingImp()
    {

        ChocolateFudge cf=new ChocolateFudge("a",90);
       String name= cf.getName();
        assertEquals("a",name,"a");
    }

}


