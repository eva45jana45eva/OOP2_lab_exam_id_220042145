import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// Test class for MinStack
public class MinStackTest {

    @Test
    public void testCase1() {
        MinStack stack = new MinStack();
        stack.push(3);
        stack.push(2);
        stack.push(5);
        stack.push(1);

        // Assert that the minimum value is 1
        assertEquals(1, stack.min(), "Expected minimum is 1 after pushing 3, 2, 5, 1");
    }

    @Test
    public void testCase2() {
        MinStack stack = new MinStack();
        stack.push(3);
        stack.push(2);
        stack.push(5);
        stack.push(1);

        // Pop once and check the min
        stack.pop(); // Remove 1
        assertEquals(2, stack.min(), "Expected minimum after popping 1 is 2");
    }

    @Test
    public void testCase3() {
        MinStack stack = new MinStack();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        // Assert that the minimum value is still 1
        assertEquals(1, stack.min(), "Expected minimum is 1 after pushing 1, 2, 3, 4");
    }
}
