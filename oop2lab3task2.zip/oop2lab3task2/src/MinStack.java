class MinStack {
    private Node top;       // Normal stack to hold the data
    private Node minTop;    // Stack to hold the minimum values

    // Constructor
    public MinStack() {
        top = null;
        minTop = null;
    }

    // Push an element onto the stack
    public void push(int x) {
        Node t = new Node(x);
        if (t == null) {
            System.out.println("Heap memory is full. Stack Overflow");
        } else {
            t.next = top;
            top = t;

            // Handle min stack
            if (minTop == null || x <= minTop.data) {
                Node minNode = new Node(x);
                minNode.next = minTop;
                minTop = minNode;
            }
        }
    }

    // Pop an element from the stack
    public int pop() {
        int x = -1;
        if (top == null) {
            System.out.println("Stack is empty. Nothing to pop.");
        } else {
            x = top.data;
            top = top.next;

            // Handle min stack
            if (x == minTop.data) {
                minTop = minTop.next;
            }
        }
        return x;
    }

    // Return the minimum value from the stack
    public int min() {
        if (minTop == null) {
            System.out.println("Stack is empty. No minimum element.");
            return -1; // Stack is empty
        } else {
            return minTop.data;
        }
    }

    // Display the stack elements
    public void display() {
        Node p = top;
        while (p != null) {
            System.out.println(p.data);
            p = p.next;
        }
    }



    // Check if the stack is empty
    public boolean isEmpty() {
        if (top == null) {
            System.out.println("Stack is empty");
            return true;
        } else {
            System.out.println("Stack is not empty");
            return false;
        }
    }


    public boolean isFull() {
        Node t = new Node(-1);
        if (t == null) {
            System.out.println("Stack is full (heap memory is exhausted)");
            return true;
        } else {
            System.out.println("Stack is not full");
            return false;
        }
    }
}